/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.GCAM.StudentManager.UI.GUI;

import fr.GCAM.StudentManager.UI.UI;
import javax.swing.JFrame;

/**
 * Classe n'ayant pas une très grande utilité pour le moment. Elle servira dans
 * le cas ou nous trouverions des specificités entre la classe GUI et la classe
 * Console.
 * Cette classe est la super-classe de l'ensemble des classes GUIECUE, GUIEtape, ...
 *
 * @author Quentin
 */
public abstract class GUI<T> extends JFrame implements UI<T> {

}
