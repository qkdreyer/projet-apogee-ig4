/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.GCAM.StudentManager.UI.Console;

import fr.GCAM.StudentManager.UI.UI;

/**
 * Classe implementant l'interface UI.
 * @author Quentin
 */
public class Console<T> implements UI<T> {

}
