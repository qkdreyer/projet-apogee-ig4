/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.GCAM.StudentManager.UI;

/**
 * Interface permettant de definir un type commun pour la console et la GUI(IHM).
 * @author Quentin
 */
public abstract interface UI<T> {

}
